package com.tuononen.petteri.phuesensor;

public class Globals {
    final String username = "e6tTyKEKc-vv5e45yX-mOKXrvM-evyIyIXCq34NZ";
}
