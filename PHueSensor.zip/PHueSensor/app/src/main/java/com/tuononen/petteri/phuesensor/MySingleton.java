package com.tuononen.petteri.phuesensor;

public class MySingleton {

        private static MySingleton single_instance = null;

        private String bridgeIP;
        private String userName;

        private MySingleton()
        {

        }

        public static MySingleton getInstance()
        {
            if (single_instance == null)
                single_instance = new MySingleton();

            return single_instance;
        }

}
