package com.tuononen.petteri.phuesensor;

public class Sensor {
    private boolean status;
    private String id;
    private String something;

    public Sensor(boolean status, String id) {
        this.status = status;
        this.id = id;
    }


}
