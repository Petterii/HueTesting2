package com.tuononen.petteri.phuesensor;

public class Bridge {

    private String id;
    private String internalipaddress;
    private String macaddress;
    private String name;

}
