package com.tuononen.petteri.phuesensor;

public interface APIcallback {
    public void ApiRequestResult(String result);
}
